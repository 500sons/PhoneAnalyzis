# ◈ PhoneAnalyzis

Android-приложение для комплексной диагностики устройств по **IMEI** и **серийному номеру (S/N)**, проверки статуса блокировок (iCloud Activation Lock / FRP / GSMA Blacklist), аудита известных уязвимостей (**CVE**) и локальной проверки безопасности текущего Android-устройства.

## ▸ Сборка APK через GitHub Actions

1. Создайте новый репозиторий на GitHub и загрузите в него содержимое этого архива (включая скрытую папку `.github/workflows/build.yml`).
2. Перейдите во вкладку **Actions** в репозитории GitHub.
3. Выберите workflow **Build PhoneAnalyzis APK** и нажмите **Run workflow** (или просто сделайте `git push` в ветку `main`/`master`).
4. После завершения сборки скачайте готовый `.apk` из раздела **Artifacts -> PhoneAnalyzis-debug-apk**.

## ◆ Модули приложения

- **IMEI & TAC Decoder**: проверка контрольной суммы по алгоритму Луна (Luhn), разбор TAC/SNR/CD и определение производителя.
- **Serial Number Analyzer**: разбор классических 12-значных и рандомизированных 10-значных серийников Apple, а также форматов Samsung/Android.
- **iCloud / Lock Status**: информация о статусе Find My / Activation Lock, MDM, FRP, Bootloader и GSMA Blacklist.
- **CVE Security Database**: база критических уязвимостей (Kernel, WebKit, Bluetooth, Framework, BootROM) с рекомендациями по защите.
- **Local Device Inspector**: диагностика текущего смартфона (версия Android, уровень патча безопасности, ADB, Root-индикаторы, ABI).
- **Export**: копирование и экспорт полного отчета в `.txt`.
