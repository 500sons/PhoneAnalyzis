# ProGuard rules for PhoneAnalyzis
-keep class com.phoneanalyzis.app.** { *; }
