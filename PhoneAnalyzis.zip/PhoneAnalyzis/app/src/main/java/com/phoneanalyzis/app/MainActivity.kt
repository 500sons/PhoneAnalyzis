package com.phoneanalyzis.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import com.phoneanalyzis.app.analyzer.DeviceAnalyzer
import com.phoneanalyzis.app.databinding.ActivityMainBinding
import com.phoneanalyzis.app.model.FullAnalysisReport
import com.phoneanalyzis.app.model.PlatformMode
import com.phoneanalyzis.app.model.SeverityLevel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedMode = PlatformMode.AUTO
    private var currentReport: FullAnalysisReport? = null
    private var activeTabIndex = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupModeButtons()
        setupActionButtons()
        setupResultTabs()
    }

    private fun setupModeButtons() {
        val buttons = listOf(
            binding.btnModeAuto to PlatformMode.AUTO,
            binding.btnModeIos to PlatformMode.IOS,
            binding.btnModeAndroid to PlatformMode.ANDROID
        )

        fun refreshModeUi() {
            buttons.forEach { (btn, mode) ->
                if (mode == selectedMode) {
                    btn.setBackgroundResource(R.drawable.bg_tab_active)
                    btn.setTextColor(ContextCompat.getColor(this, R.color.accent_cyan))
                    btn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
                } else {
                    btn.setBackgroundResource(R.drawable.bg_tab_inactive)
                    btn.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                    btn.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL)
                }
            }
        }

        buttons.forEach { (btn, mode) ->
            btn.setOnClickListener {
                selectedMode = mode
                refreshModeUi()
            }
        }
    }

    private fun setupActionButtons() {
        binding.btnPasteImei.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            val digits = text.filter { it.isDigit() }.take(15)
            if (digits.isNotEmpty()) {
                binding.etImei.setText(digits)
                Toast.makeText(this, "[✓] IMEI вставлен из буфера", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "[!] В буфере нет цифр IMEI", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnDemo.setOnClickListener {
            if (selectedMode == PlatformMode.ANDROID) {
                binding.etImei.setText("867412051234561")
                binding.etSerial.setText("R58M912345A")
            } else {
                binding.etImei.setText("354829114567893")
                binding.etSerial.setText("F2LXK890N72J")
            }
            Toast.makeText(this, "[◈] Загружены тестовые данные", Toast.LENGTH_SHORT).show()
        }

        binding.btnReset.setOnClickListener {
            binding.etImei.setText("")
            binding.etSerial.setText("")
            binding.layoutProgress.visibility = View.GONE
            binding.scrollTabs.visibility = View.GONE
            binding.layoutResults.visibility = View.GONE
            binding.layoutExport.visibility = View.GONE
            binding.layoutResults.removeAllViews()
            currentReport = null
        }

        binding.btnAnalyze.setOnClickListener {
            val imei = binding.etImei.text.toString().trim()
            val serial = binding.etSerial.text.toString().trim()

            if (imei.isEmpty() && serial.isEmpty()) {
                Toast.makeText(this, "[!] Введите IMEI или серийный номер", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            runAnimatedScan(imei, serial)
        }

        binding.btnCopyReport.setOnClickListener {
            val report = currentReport ?: return@setOnClickListener
            val text = DeviceAnalyzer.formatAsText(report)
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("PhoneAnalyzis Report", text))
            Toast.makeText(this, "[✓] Отчет скопирован в буфер обмена", Toast.LENGTH_SHORT).show()
        }

        binding.btnShareReport.setOnClickListener {
            val report = currentReport ?: return@setOnClickListener
            val text = DeviceAnalyzer.formatAsText(report)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "PhoneAnalyzis Report - ${report.imeiInfo.rawImei}")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(intent, "Экспорт отчета PhoneAnalyzis"))
        }
    }

    private fun runAnimatedScan(imei: String, serial: String) {
        binding.btnAnalyze.isEnabled = false
        binding.layoutProgress.visibility = View.VISIBLE
        binding.scrollTabs.visibility = View.GONE
        binding.layoutResults.visibility = View.GONE
        binding.layoutExport.visibility = View.GONE

        val steps = listOf(
            20 to "[*] Проверка контрольной суммы IMEI (Luhn)...",
            45 to "[*] Декодирование TAC и серийного номера...",
            70 to "[*] Анализ статуса iCloud / FRP / Blacklist...",
            90 to "[*] Сопоставление с базой уязвимостей CVE...",
            100 to "[✓] Формирование отчета безопасности..."
        )

        steps.forEachIndexed { index, (progress, label) ->
            handler.postDelayed({
                binding.progressBar.progress = progress
                binding.tvProgressStep.text = label
                if (index == steps.lastIndex) {
                    val report = DeviceAnalyzer.runFullAnalysis(this, imei, serial, selectedMode)
                    currentReport = report
                    binding.btnAnalyze.isEnabled = true
                    binding.layoutProgress.visibility = View.GONE
                    binding.scrollTabs.visibility = View.VISIBLE
                    binding.layoutResults.visibility = View.VISIBLE
                    binding.layoutExport.visibility = View.VISIBLE
                    selectResultTab(0)
                }
            }, (index + 1) * 260L)
        }
    }

    private fun setupResultTabs() {
        val tabs = listOf(
            binding.tabOverview,
            binding.tabIcloud,
            binding.tabCve,
            binding.tabLocal
        )
        tabs.forEachIndexed { idx, btn ->
            btn.setOnClickListener { selectResultTab(idx) }
        }
    }

    private fun selectResultTab(index: Int) {
        activeTabIndex = index
        val tabs = listOf(
            binding.tabOverview,
            binding.tabIcloud,
            binding.tabCve,
            binding.tabLocal
        )
        tabs.forEachIndexed { i, btn ->
            if (i == index) {
                btn.setBackgroundResource(R.drawable.bg_tab_active)
                btn.setTextColor(ContextCompat.getColor(this, R.color.accent_cyan))
                btn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            } else {
                btn.setBackgroundResource(R.drawable.bg_tab_inactive)
                btn.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                btn.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL)
            }
        }
        renderActiveTab()
    }

    private fun renderActiveTab() {
        val report = currentReport ?: return
        val container = binding.layoutResults
        container.removeAllViews()

        when (activeTabIndex) {
            0 -> renderOverviewTab(container, report)
            1 -> renderIcloudTab(container, report)
            2 -> renderCveTab(container, report)
            3 -> renderLocalTab(container, report)
        }
    }

    private fun renderOverviewTab(container: LinearLayout, r: FullAnalysisReport) {
        val scoreColor = when {
            r.securityScore >= 80 -> R.color.accent_emerald
            r.securityScore >= 55 -> R.color.accent_amber
            else -> R.color.accent_red
        }
        addCard(
            container,
            title = "◈ ИНДЕКС БЕЗОПАСНОСТИ: ${r.securityScore} / 100",
            titleColorRes = scoreColor,
            lines = listOf(
                "Платформа: ${r.platformResolved}",
                "Время сканирования: ${r.timestamp}",
                "Уязвимостей в базе: ${r.cveList.size}"
            )
        )

        val luhnStatus = if (r.imeiInfo.isLuhnValid) {
            "[✓] ВАЛИДЕН (Luhn Check OK)"
        } else {
            "[!] ОШИБКА (ожидается цифра ${r.imeiInfo.expectedCheckDigit})"
        }

        addCard(
            container,
            title = "◆ АНАЛИЗ IMEI И TAC",
            titleColorRes = R.color.accent_cyan,
            lines = listOf(
                "IMEI: ${r.imeiInfo.rawImei.ifEmpty { "-" }}",
                "Статус: $luhnStatus",
                "TAC: ${r.imeiInfo.tac}  |  SNR: ${r.imeiInfo.snr}  |  CD: ${r.imeiInfo.checkDigit}",
                "Бренд: ${r.imeiInfo.detectedBrand}",
                "Модель: ${r.imeiInfo.detectedModelHint}",
                "Орган (RBI): ${r.imeiInfo.reportingBody}"
            )
        )

        addCard(
            container,
            title = "◆ АНАЛИЗ СЕРИЙНОГО НОМЕРА (S/N)",
            titleColorRes = R.color.accent_cyan,
            lines = listOf(
                "S/N: ${r.serialInfo.rawSerial}",
                "Формат: ${r.serialInfo.formatType}",
                "Производство: ${r.serialInfo.manufacturingInfo}",
                "Год: ${r.serialInfo.yearEstimate}  |  Неделя: ${r.serialInfo.weekEstimate}"
            )
        )

        addCard(
            container,
            title = "▸ РЕКОМЕНДАЦИИ",
            titleColorRes = R.color.accent_emerald,
            lines = r.recommendations
        )
    }

    private fun renderIcloudTab(container: LinearLayout, r: FullAnalysisReport) {
        r.lockChecks.forEach { item ->
            val color = if (item.isRisk) R.color.accent_amber else R.color.accent_emerald
            addCard(
                container,
                title = "◉ ${item.title}",
                titleColorRes = color,
                lines = listOf(
                    "Статус: ${item.status}",
                    item.detail
                )
            )
        }
    }

    private fun renderCveTab(container: LinearLayout, r: FullAnalysisReport) {
        r.cveList.forEach { cve ->
            val color = when (cve.severity) {
                SeverityLevel.CRITICAL -> R.color.accent_red
                SeverityLevel.HIGH -> R.color.accent_amber
                SeverityLevel.MEDIUM -> R.color.accent_cyan
                SeverityLevel.LOW -> R.color.accent_emerald
            }
            addCard(
                container,
                title = "${cve.severity.symbol} ${cve.cveId}  [${cve.severity.label}]",
                titleColorRes = color,
                lines = listOf(
                    "Компонент: ${cve.component} (${cve.platform})",
                    "Затронуто: ${cve.affectedVersions}",
                    "Описание: ${cve.summary}",
                    "Защита: ${cve.mitigation}"
                )
            )
        }
    }

    private fun renderLocalTab(container: LinearLayout, r: FullAnalysisReport) {
        val hw = r.localHardware
        addCard(
            container,
            title = "⊞ АППАРАТНАЯ ДИАГНОСТИКА ЭТОГО СМАРТФОНА",
            titleColorRes = R.color.accent_cyan,
            lines = listOf(
                "Устройство: ${hw.manufacturer} ${hw.model}",
                "Android: ${hw.androidVersion} (API ${hw.sdkInt})",
                "Патч безопасности: ${hw.securityPatch}",
                "Bootloader: ${hw.bootloaderState}",
                "Архитектура ABI: ${hw.abiList}",
                "USB-отладка (ADB): ${if (hw.adbEnabled) "[!] ВКЛЮЧЕНА" else "[✓] ОТКЛЮЧЕНА"}",
                "Root-статус: ${if (hw.rootIndicatorsFound) "[!] ${hw.rootDetails}" else "[✓] ${hw.rootDetails}"}",
                "Fingerprint: ${hw.buildFingerprint}"
            )
        )
    }

    private fun addCard(
        parent: LinearLayout,
        title: String,
        titleColorRes: Int,
        lines: List<String>
    ) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(34, 28, 34, 28)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 24
            }
        }

        val tvTitle = TextView(this).apply {
            text = title
            setTextColor(ContextCompat.getColor(this@MainActivity, titleColorRes))
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        card.addView(tvTitle)

        lines.forEach { line ->
            val tvLine = TextView(this).apply {
                text = line
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text_primary))
                textSize = 12f
                typeface = Typeface.MONOSPACE
                setPadding(0, 10, 0, 0)
            }
            card.addView(tvLine)
        }

        parent.addView(card)
    }
}
