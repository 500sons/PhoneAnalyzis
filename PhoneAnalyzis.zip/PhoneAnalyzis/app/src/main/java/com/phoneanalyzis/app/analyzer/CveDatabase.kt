package com.phoneanalyzis.app.analyzer

import com.phoneanalyzis.app.model.CveEntry
import com.phoneanalyzis.app.model.SeverityLevel

object CveDatabase {

    private val entries = listOf(
        // iOS Advisories
        CveEntry(
            cveId = "CVE-2024-44308",
            platform = "iOS",
            component = "JavaScriptCore",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "iOS < 18.1.1 / iPadOS < 18.1.1",
            summary = "Выполнение произвольного кода при обработке вредоносного веб-контента.",
            mitigation = "Обновить до iOS 18.1.1+ и включить Lockdown Mode при высоком риске."
        ),
        CveEntry(
            cveId = "CVE-2024-44309",
            platform = "iOS",
            component = "WebKit",
            severity = SeverityLevel.HIGH,
            affectedVersions = "iOS < 18.1.1 / Safari",
            summary = "Межсайтовый скриптинг (XSS) при обработке cookie-файлов.",
            mitigation = "Установить актуальное обновление безопасности Apple."
        ),
        CveEntry(
            cveId = "CVE-2024-23222",
            platform = "iOS",
            component = "WebKit",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "iOS < 17.3 / iOS < 16.7.5",
            summary = "Type confusion в движке WebKit, позволяющий RCE через браузер.",
            mitigation = "Обновление до iOS 17.3+ или 16.7.5+."
        ),
        CveEntry(
            cveId = "CVE-2024-23296",
            platform = "iOS",
            component = "RTKit",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "iOS < 17.4",
            summary = "Повреждение памяти в RTKit для обхода защиты ядра.",
            mitigation = "Обновление до iOS 17.4+."
        ),
        CveEntry(
            cveId = "CVE-2023-42824",
            platform = "iOS",
            component = "XNU Kernel",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "iOS < 17.0.3",
            summary = "Локальное повышение привилегий в ядре XNU.",
            mitigation = "Обновление до iOS 17.0.3+."
        ),
        CveEntry(
            cveId = "CVE-2023-41993",
            platform = "iOS",
            component = "WebKit",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "iOS < 17.0.1 / 16.7",
            summary = "Уязвимость обработки веб-страниц с возможностью удаленного кода.",
            mitigation = "Обновление до iOS 17.0.1+ / 16.7+."
        ),
        CveEntry(
            cveId = "CVE-2023-32434",
            platform = "iOS",
            component = "Kernel (Integer Overflow)",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "iOS < 16.5.1",
            summary = "Выполнение кода с привилегиями ядра (использовалась в целевых атаках).",
            mitigation = "Обновление до iOS 16.5.1+."
        ),
        CveEntry(
            cveId = "CHECKM8-BOOTROM",
            platform = "iOS",
            component = "BootROM (Hardware A5-A11)",
            severity = SeverityLevel.HIGH,
            affectedVersions = "iPhone 4S - iPhone X (аппаратный DFU)",
            summary = "Аппаратная уязвимость USB DFU в процессорах A5–A11 (не исправляется ПО).",
            mitigation = "Использовать сложный код-пароль (6+ цифр) и отключать USB-аксессуары при блокировке."
        ),

        // Android Advisories
        CveEntry(
            cveId = "CVE-2024-43093",
            platform = "Android",
            component = "Android Framework",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "Android 12 / 13 / 14 / 15 (патч < Nov 2024)",
            summary = "Повышение привилегий и доступ к защищенным каталогам Android/data.",
            mitigation = "Установить патч безопасности от ноября 2024 или новее."
        ),
        CveEntry(
            cveId = "CVE-2024-36971",
            platform = "Android",
            component = "Linux Kernel (Net)",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "Android Kernel < Aug 2024 Patch",
            summary = "Use-after-free в сетевой подсистеме ядра Linux для RCE/LPE.",
            mitigation = "Обновление прошивки (патч безопасности >= 2024-08-05)."
        ),
        CveEntry(
            cveId = "CVE-2024-0044",
            platform = "Android",
            component = "PackageManager / RunAs",
            severity = SeverityLevel.HIGH,
            affectedVersions = "Android 12 - 14 (патч < Mar 2024)",
            summary = "Обход изоляции приложений через аргументы команды установки.",
            mitigation = "Отключить установку из неизвестных источников и обновить патч."
        ),
        CveEntry(
            cveId = "CVE-2023-4863",
            platform = "Android",
            component = "libwebp",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "Android / WebView / Chrome < Sep 2023",
            summary = "Переполнение буфера кучи при декодировании WebP-изображений.",
            mitigation = "Обновить Android System WebView и браузеры через Google Play."
        ),
        CveEntry(
            cveId = "CVE-2023-2136",
            platform = "Android",
            component = "Skia Graphics",
            severity = SeverityLevel.HIGH,
            affectedVersions = "Android / Chrome < May 2023",
            summary = "Целочисленное переполнение в графической библиотеке Skia.",
            mitigation = "Обновить Chrome / WebView и системные патчи."
        ),
        CveEntry(
            cveId = "CVE-2020-0022",
            platform = "Android",
            component = "Bluetooth (BlueFrag)",
            severity = SeverityLevel.CRITICAL,
            affectedVersions = "Android 8.0 - 9.0",
            summary = "Удаленное выполнение кода по Bluetooth без взаимодействия с пользователем.",
            mitigation = "Отключать Bluetooth при простое, обновить ОС до Android 10+."
        ),
        CveEntry(
            cveId = "CVE-2024-32896",
            platform = "Android",
            component = "Pixel / Android Firmware",
            severity = SeverityLevel.HIGH,
            affectedVersions = "Android < Jun 2024 Patch",
            summary = "Повышение привилегий на уровне системного фреймворка.",
            mitigation = "Установить обновление безопасности от июня 2024+."
        )
    )

    fun getForPlatform(platform: String): List<CveEntry> {
        return when {
            platform.contains("iOS", ignoreCase = true) ->
                entries.filter { it.platform == "iOS" }
            platform.contains("Android", ignoreCase = true) ->
                entries.filter { it.platform == "Android" }
            else -> entries
        }
    }
}
