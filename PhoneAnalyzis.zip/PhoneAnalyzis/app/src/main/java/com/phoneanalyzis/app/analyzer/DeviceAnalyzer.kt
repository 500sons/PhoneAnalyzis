package com.phoneanalyzis.app.analyzer

import android.content.Context
import com.phoneanalyzis.app.model.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DeviceAnalyzer {

    fun runFullAnalysis(
        context: Context,
        imeiInput: String,
        serialInput: String,
        mode: PlatformMode
    ): FullAnalysisReport {
        val imeiInfo = ImeiDecoder.analyze(imeiInput)
        val serialInfo = SerialDecoder.analyze(serialInput)
        val localHw = LocalDeviceInspector.inspect(context)

        val resolvedPlatform = when (mode) {
            PlatformMode.IOS -> "iOS / Apple"
            PlatformMode.ANDROID -> "Android"
            PlatformMode.AUTO -> {
                when {
                    imeiInfo.detectedBrand.contains("Apple", ignoreCase = true) ||
                        serialInfo.probablePlatform.contains("iOS", ignoreCase = true) -> "iOS / Apple"
                    else -> "Android"
                }
            }
        }

        val lockChecks = buildLockChecks(resolvedPlatform, imeiInfo, serialInfo)
        val cves = CveDatabase.getForPlatform(resolvedPlatform)

        var score = 100
        if (!imeiInfo.isLuhnValid) score -= 25
        if (serialInfo.length == 0) score -= 15
        if (localHw.rootIndicatorsFound) score -= 20
        if (localHw.adbEnabled) score -= 10
        if (cves.any { it.severity == SeverityLevel.CRITICAL }) score -= 10
        score = score.coerceIn(10, 100)

        val recommendations = buildList {
            if (!imeiInfo.isLuhnValid) {
                add("[!] Контрольная цифра IMEI не прошла проверку Луна — перепроверьте 15 цифр (*#06#).")
            } else {
                add("[✓] IMEI корректен по стандарту GSMA (Luhn Check пройден).")
            }
            if (resolvedPlatform.contains("iOS")) {
                add("[*] Перед покупкой iPhone убедитесь, что Find My (iCloud Activation Lock) полностью отключен в настройках.")
                add("[*] Сверьте IMEI в Настройках -> Основные -> Об этом устройстве с лотком SIM и коробкой.")
            } else {
                add("[*] Проверьте статус Factory Reset Protection (FRP) и отвяжите Google/Mi аккаунт перед сбросом.")
                if (localHw.adbEnabled) {
                    add("[!] На текущем устройстве включена отладка по USB (ADB) — отключайте при зарядке в общественных местах.")
                }
            }
            add("[◆] Регулярно устанавливайте актуальные патчи безопасности для закрытия критических CVE.")
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return FullAnalysisReport(
            timestamp = sdf.format(Date()),
            platformResolved = resolvedPlatform,
            securityScore = score,
            imeiInfo = imeiInfo,
            serialInfo = serialInfo,
            lockChecks = lockChecks,
            cveList = cves,
            localHardware = localHw,
            recommendations = recommendations
        )
    }

    private fun buildLockChecks(
        platform: String,
        imei: ImeiInfo,
        serial: SerialInfo
    ): List<LockStatusItem> {
        val list = mutableListOf<LockStatusItem>()

        if (platform.contains("iOS")) {
            list.add(
                LockStatusItem(
                    title = "iCloud / Activation Lock (FMI)",
                    status = "ТРЕБУЕТ ОНЛАЙН-ВЕРИФИКАЦИИ",
                    detail = "Локальный оффлайн-анализ не имеет доступа к закрытым серверам Apple GSX. Проверьте статус Find My iPhone через официальный чек при входе в Apple ID или сбросе.",
                    isRisk = true
                )
            )
            list.add(
                LockStatusItem(
                    title = "MDM / Corporate Supervision",
                    status = "ПРОВЕРКА ПРОФИЛЯ",
                    detail = "Убедитесь в отсутствии профиля удаленного управления в Настройки -> Основные -> VPN и управление устройством.",
                    isRisk = false
                )
            )
        } else {
            list.add(
                LockStatusItem(
                    title = "Google FRP / Mi Account Lock",
                    status = "ПРОВЕРКА ПРИВЯЗКИ",
                    detail = "Защита Factory Reset Protection активна, если на устройстве выполнен вход в Google/Xiaomi аккаунт.",
                    isRisk = false
                )
            )
            list.add(
                LockStatusItem(
                    title = "Bootloader & Verified Boot",
                    status = "ТРЕБУЕТСЯ ПРОВЕРКА OEM",
                    detail = "Разблокированный загрузчик снижает целостность системы и отключает аппаратный кейстор для некоторых банковских приложений.",
                    isRisk = false
                )
            )
        }

        list.add(
            LockStatusItem(
                title = "GSMA IMEI Blacklist (Lost / Stolen)",
                status = if (imei.isLuhnValid) "ФОРМАТ ВАЛИДЕН (НУЖЕН API)" else "ОШИБКА ФОРМАТА IMEI",
                detail = if (imei.isLuhnValid) {
                    "TAC ${imei.tac} валиден. Для проверки на кражу/утерю в сетях операторов используйте официальный реестр GSMA/оператора."
                } else {
                    "Некорректная контрольная сумма IMEI (ожидается ${imei.expectedCheckDigit})."
                },
                isRisk = !imei.isLuhnValid
            )
        )

        list.add(
            LockStatusItem(
                title = "SIM / Carrier Lock",
                status = "ПРОВЕРКА ОПЕРАТОРА",
                detail = "Проверьте работу с SIM-картой другого оператора (в iOS: Настройки -> Об этом устройстве -> Блокировка оператора: Без ограничений).",
                isRisk = false
            )
        )

        if (serial.length > 0) {
            list.add(
                LockStatusItem(
                    title = "Соответствие S/N и платформы",
                    status = "[✓] СЕРИЙНИК РАСПОЗНАН (${serial.formatType})",
                    detail = "${serial.manufacturingInfo} | Оценка года: ${serial.yearEstimate}",
                    isRisk = false
                )
            )
        }

        return list
    }

    fun formatAsText(report: FullAnalysisReport): String {
        val sb = StringBuilder()
        sb.appendLine("========================================")
        sb.appendLine("◈ PHONEANALYZIS // ОТЧЕТ ДИАГНОСТИКИ")
        sb.appendLine("========================================")
        sb.appendLine("Время: ${report.timestamp}")
        sb.appendLine("Платформа: ${report.platformResolved}")
        sb.appendLine("Индекс безопасности: ${report.securityScore}/100")
        sb.appendLine()
        sb.appendLine("▸ [1] IMEI АНАЛИЗ")
        sb.appendLine("  IMEI: ${report.imeiInfo.rawImei}")
        sb.appendLine("  Luhn Check: ${if (report.imeiInfo.isLuhnValid) "VALID" else "INVALID (ожидается ${report.imeiInfo.expectedCheckDigit})"}")
        sb.appendLine("  TAC: ${report.imeiInfo.tac} | SNR: ${report.imeiInfo.snr} | CD: ${report.imeiInfo.checkDigit}")
        sb.appendLine("  Бренд: ${report.imeiInfo.detectedBrand}")
        sb.appendLine("  Модель: ${report.imeiInfo.detectedModelHint}")
        sb.appendLine("  Орган регистрации: ${report.imeiInfo.reportingBody}")
        sb.appendLine()
        sb.appendLine("▸ [2] СЕРИЙНЫЙ НОМЕР")
        sb.appendLine("  S/N: ${report.serialInfo.rawSerial}")
        sb.appendLine("  Формат: ${report.serialInfo.formatType}")
        sb.appendLine("  Производство: ${report.serialInfo.manufacturingInfo}")
        sb.appendLine("  Год / Неделя: ${report.serialInfo.yearEstimate} / ${report.serialInfo.weekEstimate}")
        sb.appendLine()
        sb.appendLine("▸ [3] СТАТУС iCLOUD И БЛОКИРОВОК")
        report.lockChecks.forEach {
            sb.appendLine("  ◆ ${it.title}: ${it.status}")
            sb.appendLine("    ${it.detail}")
        }
        sb.appendLine()
        sb.appendLine("▸ [4] ИЗВЕСТНЫЕ УЯЗВИМОСТИ (${report.cveList.size})")
        report.cveList.forEach {
            sb.appendLine("  ${it.severity.symbol} ${it.cveId} [${it.severity.label}] - ${it.component}")
            sb.appendLine("    Версии: ${it.affectedVersions}")
            sb.appendLine("    Суть: ${it.summary}")
            sb.appendLine("    Защита: ${it.mitigation}")
        }
        sb.appendLine()
        sb.appendLine("▸ [5] РЕКОМЕНДАЦИИ")
        report.recommendations.forEach { sb.appendLine("  $it") }
        sb.appendLine("========================================")
        return sb.toString()
    }
}
