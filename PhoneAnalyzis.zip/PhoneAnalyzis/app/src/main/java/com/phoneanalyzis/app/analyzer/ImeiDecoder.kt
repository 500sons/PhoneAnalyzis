package com.phoneanalyzis.app.analyzer

import com.phoneanalyzis.app.model.ImeiInfo

object ImeiDecoder {

    private data class TacEntry(val brand: String, val model: String)

    private val tacDatabase = mapOf(
        "35391510" to TacEntry("Apple", "iPhone 12 / 12 Pro Series"),
        "35674111" to TacEntry("Apple", "iPhone 13 / 13 Pro Series"),
        "35482911" to TacEntry("Apple", "iPhone 14 Pro / Pro Max"),
        "35574284" to TacEntry("Apple", "iPhone 15 / 15 Pro Series"),
        "35201908" to TacEntry("Apple", "iPhone X / XS Series"),
        "35301111" to TacEntry("Apple", "iPhone 11 Series"),
        "35897210" to TacEntry("Samsung", "Galaxy S21 / S22 Ultra"),
        "35247811" to TacEntry("Samsung", "Galaxy S23 / S24 Series"),
        "35699510" to TacEntry("Samsung", "Galaxy A54 / A55 5G"),
        "86741205" to TacEntry("Xiaomi / POCO", "POCO M6 Pro / Redmi Note 13"),
        "86394506" to TacEntry("Xiaomi / POCO", "POCO F5 / F6 Pro"),
        "86918205" to TacEntry("Xiaomi", "Xiaomi 13 / 14 Series"),
        "35847631" to TacEntry("Google", "Pixel 7 / 8 Pro"),
        "35412209" to TacEntry("Google", "Pixel 9 Series"),
        "86123404" to TacEntry("Huawei", "P / Mate Series"),
        "86451206" to TacEntry("OnePlus", "OnePlus 11 / 12 Series")
    )

    private val reportingBodies = mapOf(
        "00" to "PTCRB / CTIA (Test / North America)",
        "01" to "CTIA (USA)",
        "35" to "BABT (UK / Global GSM)",
        "44" to "BABT (UK)",
        "45" to "DEKRA / Europe",
        "49" to "CETECOM (Germany)",
        "86" to "TAF / MIIT (China)",
        "91" to "MSAI (India)"
    )

    fun analyze(input: String): ImeiInfo {
        val clean = input.filter { it.isDigit() }
        val isLen = clean.length == 15
        val tac = if (clean.length >= 8) clean.substring(0, 8) else clean.padEnd(8, '0')
        val snr = if (clean.length >= 14) clean.substring(8, 14) else "------"
        val cd = if (clean.length == 15) clean.substring(14, 15) else "-"

        val expectedCd = if (clean.length >= 14) computeLuhnDigit(clean.substring(0, 14)) else "-"
        val luhnValid = isLen && (cd == expectedCd)

        val exactTac = tacDatabase[tac]
        val prefix2 = tac.take(2)
        val rbi = reportingBodies[prefix2] ?: "GSMA Allocated ($prefix2)"

        val brandGuess: String
        val modelGuess: String
        if (exactTac != null) {
            brandGuess = exactTac.brand
            modelGuess = exactTac.model
        } else {
            when (prefix2) {
                "35" -> {
                    brandGuess = "Apple / Samsung / Google (BABT TAC)"
                    modelGuess = "Требуется онлайн TAC-запрос для точной модели"
                }
                "86" -> {
                    brandGuess = "Xiaomi / POCO / OnePlus / Huawei (TAF TAC)"
                    modelGuess = "Требуется онлайн TAC-запрос для точной модели"
                }
                else -> {
                    brandGuess = "Неизвестный производитель (TAC: $tac)"
                    modelGuess = "Модель не найдена в локальном кэше"
                }
            }
        }

        return ImeiInfo(
            rawImei = clean,
            isLengthValid = isLen,
            isLuhnValid = luhnValid,
            tac = tac,
            snr = snr,
            checkDigit = cd,
            expectedCheckDigit = expectedCd,
            detectedBrand = brandGuess,
            detectedModelHint = modelGuess,
            reportingBody = rbi
        )
    }

    fun computeLuhnDigit(first14: String): String {
        if (first14.length != 14 || !first14.all { it.isDigit() }) return "-"
        var sum = 0
        for (i in 0 until 14) {
            var digit = first14[i] - '0'
            if (i % 2 == 1) {
                digit *= 2
                if (digit > 9) digit -= 9
            }
            sum += digit
        }
        val check = (10 - (sum % 10)) % 10
        return check.toString()
    }
}
