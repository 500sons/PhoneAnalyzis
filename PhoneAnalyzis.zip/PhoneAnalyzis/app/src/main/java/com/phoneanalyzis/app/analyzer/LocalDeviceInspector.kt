package com.phoneanalyzis.app.analyzer

import android.content.Context
import android.os.Build
import android.provider.Settings
import com.phoneanalyzis.app.model.LocalHardwareReport
import java.io.File

object LocalDeviceInspector {

    fun inspect(context: Context): LocalHardwareReport {
        val rootPaths = listOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su"
        )
        val foundPaths = rootPaths.filter { File(it).exists() }
        val testKeys = Build.TAGS?.contains("test-keys") == true
        val rootDetected = foundPaths.isNotEmpty() || testKeys

        val rootSummary = when {
            foundPaths.isNotEmpty() -> "Обнаружены бинарники: ${foundPaths.joinToString(", ")}"
            testKeys -> "Обнаружены test-keys в Build.TAGS"
            else -> "Признаки Root / su не обнаружены"
        }

        val adbEnabled = try {
            Settings.Global.getInt(context.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        } catch (_: Exception) {
            false
        }

        val securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH
        } else {
            "N/A (API < 23)"
        }

        val bootloader = Build.BOOTLOADER ?: "unknown"

        return LocalHardwareReport(
            manufacturer = Build.MANUFACTURER.uppercase(),
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = securityPatch,
            buildFingerprint = Build.FINGERPRINT,
            abiList = Build.SUPPORTED_ABIS.joinToString(", "),
            rootIndicatorsFound = rootDetected,
            rootDetails = rootSummary,
            adbEnabled = adbEnabled,
            bootloaderState = bootloader
        )
    }
}
