package com.phoneanalyzis.app.analyzer

import com.phoneanalyzis.app.model.SerialInfo

object SerialDecoder {

    private val appleFactories = mapOf(
        "C02" to "Quanta Computer (Китай)",
        "C07" to "Foxconn (Чжэнчжоу / Шэньчжэнь)",
        "C39" to "Foxconn (Шэньчжэнь, Китай)",
        "DNQ" to "Foxconn (Чэнду, Китай)",
        "F17" to "Foxconn (Чжэнчжоу, Китай)",
        "F2L" to "Foxconn (Чжэнчжоу, Китай)",
        "FK1" to "Foxconn (Чжэнчжоу, Китай)",
        "G0N" to "Pegatron (Шанхай, Китай)",
        "G6T" to "Foxconn (Чжэнчжоу, Китай)",
        "C8Q" to "Pegatron (Китай)",
        "DLC" to "Foxconn (Индия / Китай)"
    )

    private val appleYearChars = mapOf(
        'C' to "2010 / 2020 (H1)",
        'D' to "2010 / 2020 (H2)",
        'F' to "2011 / 2021 (H1)",
        'G' to "2011 / 2021 (H2)",
        'H' to "2012",
        'J' to "2012",
        'K' to "2013",
        'L' to "2013",
        'M' to "2014",
        'N' to "2014",
        'P' to "2015",
        'Q' to "2015",
        'R' to "2016",
        'S' to "2016",
        'T' to "2017",
        'V' to "2017",
        'W' to "2018",
        'X' to "2018",
        'Y' to "2019",
        'Z' to "2019"
    )

    fun analyze(input: String): SerialInfo {
        val sn = input.trim().uppercase()
        if (sn.isEmpty()) {
            return SerialInfo(
                rawSerial = "-",
                length = 0,
                formatType = "Не указан",
                probablePlatform = "Не определена",
                manufacturingInfo = "Введите серийный номер",
                yearEstimate = "-",
                weekEstimate = "-"
            )
        }

        // Apple 10-char randomized serial (iPhone 12 purple+, iPhone 13..16)
        if (sn.length == 10 && sn.all { it.isLetterOrDigit() }) {
            return SerialInfo(
                rawSerial = sn,
                length = 10,
                formatType = "Apple Randomized S/N (10 символов)",
                probablePlatform = "iOS / Apple (2021+)",
                manufacturingInfo = "Рандомизированный серийный номер Apple (дата производства скрыта)",
                yearEstimate = "2021+",
                weekEstimate = "Зашифровано в случайной строке"
            )
        }

        // Apple 12-char classic serial
        if (sn.length == 12 && sn.all { it.isLetterOrDigit() }) {
            val factoryPrefix = sn.take(3)
            val factoryName = appleFactories[factoryPrefix] ?: "Фабрика Apple (код $factoryPrefix)"
            val yearChar = sn[3]
            val weekChar = sn[4]
            val yearDesc = appleYearChars[yearChar] ?: "Код года: $yearChar"
            val weekDesc = "Код недели: $weekChar (полугодие)"

            return SerialInfo(
                rawSerial = sn,
                length = 12,
                formatType = "Apple Classic S/N (12 символов)",
                probablePlatform = "iOS / Apple",
                manufacturingInfo = factoryName,
                yearEstimate = yearDesc,
                weekEstimate = weekDesc
            )
        }

        // Samsung 11-char S/N (e.g. R58...)
        if (sn.length == 11 && (sn.startsWith("R") || sn.startsWith("RF") || sn.startsWith("RZ"))) {
            return SerialInfo(
                rawSerial = sn,
                length = 11,
                formatType = "Samsung Serial Format (11 символов)",
                probablePlatform = "Android (Samsung)",
                manufacturingInfo = "Префикс завода Samsung: ${sn.take(3)}",
                yearEstimate = "Код года: ${sn.getOrElse(3) { '-' }}",
                weekEstimate = "Код месяца: ${sn.getOrElse(4) { '-' }}"
            )
        }

        // Xiaomi / POCO / Generic Android
        return SerialInfo(
            rawSerial = sn,
            length = sn.length,
            formatType = "Android / Generic OEM S/N (${sn.length} симв.)",
            probablePlatform = "Android / Универсальный",
            manufacturingInfo = "Префикс партии: ${sn.take(4)}",
            yearEstimate = "Зависит от OEM",
            weekEstimate = "Локальный формат"
        )
    }
}
