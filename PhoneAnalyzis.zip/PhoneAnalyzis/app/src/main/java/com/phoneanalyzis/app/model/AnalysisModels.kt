package com.phoneanalyzis.app.model

enum class PlatformMode {
    AUTO, IOS, ANDROID
}

enum class SeverityLevel(val label: String, val symbol: String) {
    CRITICAL("CRITICAL", "[!]"),
    HIGH("HIGH", "[▲]"),
    MEDIUM("MEDIUM", "[◆]"),
    LOW("LOW", "[○]")
}

data class ImeiInfo(
    val rawImei: String,
    val isLengthValid: Boolean,
    val isLuhnValid: Boolean,
    val tac: String,
    val snr: String,
    val checkDigit: String,
    val expectedCheckDigit: String,
    val detectedBrand: String,
    val detectedModelHint: String,
    val reportingBody: String
)

data class SerialInfo(
    val rawSerial: String,
    val length: Int,
    val formatType: String,
    val probablePlatform: String,
    val manufacturingInfo: String,
    val yearEstimate: String,
    val weekEstimate: String
)

data class LockStatusItem(
    val title: String,
    val status: String,
    val detail: String,
    val isRisk: Boolean
)

data class CveEntry(
    val cveId: String,
    val platform: String,
    val component: String,
    val severity: SeverityLevel,
    val affectedVersions: String,
    val summary: String,
    val mitigation: String
)

data class LocalHardwareReport(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val securityPatch: String,
    val buildFingerprint: String,
    val abiList: String,
    val rootIndicatorsFound: Boolean,
    val rootDetails: String,
    val adbEnabled: Boolean,
    val bootloaderState: String
)

data class FullAnalysisReport(
    val timestamp: String,
    val platformResolved: String,
    val securityScore: Int,
    val imeiInfo: ImeiInfo,
    val serialInfo: SerialInfo,
    val lockChecks: List<LockStatusItem>,
    val cveList: List<CveEntry>,
    val localHardware: LocalHardwareReport,
    val recommendations: List<String>
)
